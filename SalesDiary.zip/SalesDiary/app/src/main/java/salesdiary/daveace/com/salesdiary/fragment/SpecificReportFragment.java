package salesdiary.daveace.com.salesdiary.fragment;

import android.support.v4.app.Fragment;

public class SpecificReportFragment extends Fragment {
}
