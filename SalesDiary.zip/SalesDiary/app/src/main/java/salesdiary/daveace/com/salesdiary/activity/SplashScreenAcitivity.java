package salesdiary.daveace.com.salesdiary.activity;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import salesdiary.daveace.com.salesdiary.R;

public class SplashScreenAcitivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        loadSplashScreen();
    }

    private void loadSplashScreen() {
        final int LOAD_TIME = 3000;
        new Handler().postDelayed(() -> {
                    Intent signUpIntent = new Intent(SplashScreenAcitivity.this, SignUpActivity.class);
                    startActivity(signUpIntent);
                    finish();
                }
                , LOAD_TIME);
    }
}
