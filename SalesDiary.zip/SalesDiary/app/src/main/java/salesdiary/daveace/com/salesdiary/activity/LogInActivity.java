package salesdiary.daveace.com.salesdiary.activity;

import android.support.v7.app.AppCompatActivity;

public class LogInActivity extends AppCompatActivity {
}
